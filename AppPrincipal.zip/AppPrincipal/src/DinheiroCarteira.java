
public class DinheiroCarteira {
    static float quantia;

    public static float getQuantia() {
        return quantia;
    }

    public static void setQuantia(float quantia) {
        DinheiroCarteira.quantia = quantia;
    }
    @Override
    public String toString() {
        return "DinheiroCarteira []";
    }
   
    
}

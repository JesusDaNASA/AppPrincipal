
interface iConta {
    void debitar(float valor);
    void depositar(float valor);
    void reterLimite(float valor);
    void retornarLimite(float valor);
   
}


public class Usuario {
    
}
